#include <stdio.h>
int main() {    

    int number1=10, number2=20, sum;
    

    
    sum = number1 + number2;      
    
    printf("%d + %d = %d", number1, number2, sum);
    return 0;
}
